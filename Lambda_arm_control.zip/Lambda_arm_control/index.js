var APP_ID = "amzn1.ask.skill.b9c6f2ee-6d54-48c5-89be-e1fefb0aa1cf"; // input the axela skill ID
var AWS = require('aws-sdk');
var Alexa = require("alexa-sdk");

AWS.config.region = "us-east-1";
var iotData = new AWS.IotData({endpoint: "a2hrbj4onpnif8-ats.iot.us-east-1.amazonaws.com"}); // input the AWS thing end point
var topic = "ARM"; //input the topic that the device is subscribed to

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};



var handlers = {

	'LaunchRequest': function () {
        this.emit(':tell', 'Hello. How may I help you?');
   },

	
    'DoorIntent': function () {
      var params = {
          topic: topic,
          payload: "door",
          qos:0
      };
      iotData.publish(params, (error, data)=>{
          if (!error){this.emit(':tell', 'Opening the door');
              
          }else{this.emit(':tell', 'Something went wrong')}
        });

    },
    'BottleIntent': function () {
      var params = {
          topic: topic,
          payload: "bottle",
          qos:0
      };
      iotData.publish(params, (error, data)=>{
          if (!error){this.emit(':tell', 'Ok');
              
          }else{this.emit(':tell', 'Something went wrong')}
        });

    },
    'Unhandled': function () {
        this.emit(':tell', 'sorry');
    }
};